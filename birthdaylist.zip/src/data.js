export const list=[
    {
      "_id": 0,
      "name": "Logan Warren",
      "gender": "male",
      "email": "loganwarren@exposa.com",
      "phone": "+1 (950) 520-3803",
      "day": 11,
      "month": 12,
      "year": 2005
    },
    {
      "_id": 1,
      "name": "Sweet Lang",
      "gender": "male",
      "email": "sweetlang@exposa.com",
      "phone": "+1 (946) 401-2362",
      "day": 5,
      "month": 10,
      "year": 2008
    },
    {
      "_id": 2,
      "name": "Chen Obrien",
      "gender": "male",
      "email": "chenobrien@exposa.com",
      "phone": "+1 (863) 547-3747",
      "day": 12,
      "month": 4,
      "year": 1998
    },
    {
      "_id": 3,
      "name": "Hart Montoya",
      "gender": "male",
      "email": "hartmontoya@exposa.com",
      "phone": "+1 (923) 462-3594",
      "day": 5,
      "month": 1,
      "year": 2018
    },
    {
      "_id": 4,
      "name": "Anne Christian",
      "gender": "female",
      "email": "annechristian@exposa.com",
      "phone": "+1 (842) 471-2575",
      "day": 7,
      "month": 10,
      "year": 2007
    },
    {
      "_id": 5,
      "name": "Brown Blackburn",
      "gender": "male",
      "email": "brownblackburn@exposa.com",
      "phone": "+1 (930) 535-2294",
      "day": 10,
      "month": 12,
      "year": 2017
    },
    {
      "_id": 6,
      "name": "Perkins Stafford",
      "gender": "male",
      "email": "perkinsstafford@exposa.com",
      "phone": "+1 (800) 588-2800",
      "day": 5,
      "month": 5,
      "year": 2009
    },
    {
      "_id": 7,
      "name": "Neal David",
      "gender": "male",
      "email": "nealdavid@exposa.com",
      "phone": "+1 (808) 553-3616",
      "day": 12,
      "month": 11,
      "year": 1993
    },
    {
      "_id": 8,
      "name": "Barber Harris",
      "gender": "male",
      "email": "barberharris@exposa.com",
      "phone": "+1 (925) 529-3660",
      "day": 1,
      "month": 6,
      "year": 2023
    },
    {
      "_id": 9,
      "name": "Kathleen Ayala",
      "gender": "female",
      "email": "kathleenayala@exposa.com",
      "phone": "+1 (856) 556-3939",
      "day": 12,
      "month": 12,
      "year": 2021
    },
    {
      "_id": 10,
      "name": "Mabel Pearson",
      "gender": "female",
      "email": "mabelpearson@exposa.com",
      "phone": "+1 (854) 514-3610",
      "day": 2,
      "month": 2,
      "year": 2012
    },
    {
      "_id": 11,
      "name": "Greer Chandler",
      "gender": "male",
      "email": "greerchandler@exposa.com",
      "phone": "+1 (887) 486-3519",
      "day": 6,
      "month": 8,
      "year": 2018
    },
    {
      "_id": 12,
      "name": "Crystal Romero",
      "gender": "female",
      "email": "crystalromero@exposa.com",
      "phone": "+1 (951) 564-3916",
      "day": 20,
      "month": 5,
      "year": 2004
    },
    {
      "_id": 13,
      "name": "Ladonna Mercado",
      "gender": "female",
      "email": "ladonnamercado@exposa.com",
      "phone": "+1 (949) 575-2384",
      "day": 25,
      "month": 8,
      "year": 2012
    },
    {
      "_id": 14,
      "name": "Vincent Sandoval",
      "gender": "male",
      "email": "vincentsandoval@exposa.com",
      "phone": "+1 (880) 573-3644",
      "day": 14,
      "month": 5,
      "year": 2010
    },
    {
      "_id": 15,
      "name": "Guthrie Blake",
      "gender": "male",
      "email": "guthrieblake@exposa.com",
      "phone": "+1 (858) 427-2889",
      "day": 4,
      "month": 2,
      "year": 2010
    },
    {
      "_id": 16,
      "name": "Edna Gallagher",
      "gender": "female",
      "email": "ednagallagher@exposa.com",
      "phone": "+1 (807) 460-2644",
      "day": 15,
      "month": 7,
      "year": 2007
    },
    {
      "_id": 17,
      "name": "Erna Haley",
      "gender": "female",
      "email": "ernahaley@exposa.com",
      "phone": "+1 (813) 502-3781",
      "day": 12,
      "month": 1,
      "year": 2007
    },
    {
      "_id": 18,
      "name": "Erma Austin",
      "gender": "female",
      "email": "ermaaustin@exposa.com",
      "phone": "+1 (993) 402-2996",
      "day": 4,
      "month": 8,
      "year": 2020
    },
    {
      "_id": 19,
      "name": "Genevieve Nunez",
      "gender": "female",
      "email": "genevievenunez@exposa.com",
      "phone": "+1 (986) 474-2150",
      "day": 18,
      "month": 6,
      "year": 2018
    },
    {
      "_id": 20,
      "name": "Curry Silva",
      "gender": "male",
      "email": "currysilva@exposa.com",
      "phone": "+1 (979) 543-3750",
      "day": 17,
      "month": 2,
      "year": 2015
    },
    {
      "_id": 21,
      "name": "Janelle Barnes",
      "gender": "female",
      "email": "janellebarnes@exposa.com",
      "phone": "+1 (808) 583-2459",
      "day": 26,
      "month": 4,
      "year": 1992
    },
    {
      "_id": 22,
      "name": "Barbra Farley",
      "gender": "female",
      "email": "barbrafarley@exposa.com",
      "phone": "+1 (838) 534-2975",
      "day": 18,
      "month": 10,
      "year": 1991
    },
    {
      "_id": 23,
      "name": "Bertha Chan",
      "gender": "female",
      "email": "berthachan@exposa.com",
      "phone": "+1 (865) 484-2720",
      "day": 6,
      "month": 8,
      "year": 2011
    },
    {
      "_id": 24,
      "name": "Irwin Schmidt",
      "gender": "male",
      "email": "irwinschmidt@exposa.com",
      "phone": "+1 (973) 553-3942",
      "day": 7,
      "month": 5,
      "year": 2012
    },
    {
      "_id": 25,
      "name": "Selma Carroll",
      "gender": "female",
      "email": "selmacarroll@exposa.com",
      "phone": "+1 (841) 486-3882",
      "day": 19,
      "month": 12,
      "year": 2004
    },
    {
      "_id": 26,
      "name": "Castaneda Mckay",
      "gender": "male",
      "email": "castanedamckay@exposa.com",
      "phone": "+1 (803) 582-3380",
      "day": 11,
      "month": 10,
      "year": 1997
    },
    {
      "_id": 27,
      "name": "Carr Meyers",
      "gender": "male",
      "email": "carrmeyers@exposa.com",
      "phone": "+1 (859) 481-3868",
      "day": 16,
      "month": 11,
      "year": 2003
    },
    {
      "_id": 28,
      "name": "Barlow Perkins",
      "gender": "male",
      "email": "barlowperkins@exposa.com",
      "phone": "+1 (997) 414-3475",
      "day": 3,
      "month": 9,
      "year": 2004
    },
    {
      "_id": 29,
      "name": "Suzette Dillard",
      "gender": "female",
      "email": "suzettedillard@exposa.com",
      "phone": "+1 (804) 599-3081",
      "day": 26,
      "month": 10,
      "year": 1991
    }
  ]